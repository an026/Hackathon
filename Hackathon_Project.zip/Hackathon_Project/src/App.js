import './App.css';
import Dictaphone from './Dictaphone';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (<>
    <div id="App">
      <Dictaphone class="d-flex"></Dictaphone>
    </div>
    </>
  );
}

export default App;
